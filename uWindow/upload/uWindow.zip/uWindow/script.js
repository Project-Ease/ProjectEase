$(document).ready(function(){
  console.log("hey there");
})
$("#teams").click( function(){
    $("#code-upload-win").html("<h1>hey there upload your code here</h1>");
})
